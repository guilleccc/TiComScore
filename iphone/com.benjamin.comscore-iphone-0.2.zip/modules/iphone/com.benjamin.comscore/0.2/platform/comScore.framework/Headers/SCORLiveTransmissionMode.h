//
// Copyright (c) 2016 comScore. All rights reserved.
//

typedef enum {
    SCORLiveTransmissionModeCache = 20003,
    SCORLiveTransmissionModeLan = 20002,
    SCORLiveTransmissionModeStandard = 20001
} SCORLiveTransmissionMode;